# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-Ec2LaunchVersion sends EC2 Launch version to console.
-------------------------------------------------------------------------------------------------------------#>
function Send-Ec2LaunchVersion 
{
    try
    {
        # Get the Ec2Launch Module 
        $ec2LaunchModule = Get-Module -Name "Ec2Launch" -ErrorAction SilentlyContinue
        if ($ec2LaunchModule) 
        {
            Write-Log ("Launch: EC2 Launch v{0}" -f $ec2LaunchModule.Version) -LogToConsole
        }
    }
    catch
    {
        Write-Log ("Failed to send Ec2Launch version: {0}" -f $_.Exception.Message)
    }
}