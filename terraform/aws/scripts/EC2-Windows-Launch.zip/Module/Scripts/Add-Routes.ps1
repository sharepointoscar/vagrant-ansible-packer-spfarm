# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Add-Routes routes connections to metadata service and KMS VPC 1 & 2.
-------------------------------------------------------------------------------------------------------------#>
function Add-Routes
{   
    # 169.254.169.254 is for metadata service
    # 169.254.169.250 is for KmsInstanceVpc1
    # 169.254.169.251 is for KmsInstanceVpc2
    $ipAddrs = @("169.254.169.254/32", "169.254.169.250/32", "169.254.169.251/32")
    
    $sleepTime = 1
    $count = 0

    # Retry logic for querying primary network interface and adding routes.
    while($true)
    {
        try
        {
            Write-Log "Checking primary network interface"

            # If the current platform is not Nano, use this implementation for a better performance.
            if (-not (Test-NanoServer))
            {
                $networkAdapter = Get-CimInstance -ClassName Win32_NetworkAdapter -Filter "AdapterTypeId='0' AND NetEnabled='True' AND NOT Name LIKE '%Hyper-V Virtual%' AND NOT Name LIKE '%Loopback Adapter%' AND NOT Name LIKE '%TAP-Windows Adapter%'" | Sort-Object -Property "InterfaceIndex" | select InterfaceIndex
                if(-not $networkAdapter -or $networkAdapter.Length -eq 0) 
                {
                    throw New-Object System.Exception("Failed to find the primary network interface")
                }
                $interfaceIndex = $networkAdapter[0].InterfaceIndex
                $networkAdapterConfig = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "InterfaceIndex='$interfaceIndex'" | select IPConnectionMetric, DefaultIPGateway
                $defaultGateway = $networkAdapterConfig.DefaultIPGateway[$networkAdapterConfig.DefaultIPGateway.Length - 1]
                $interfaceMetric = $networkAdapterConfig.IPConnectionMetric
            }
            else
            {
                $ipConfigs = Get-NetIPConfiguration | Sort-Object -Property "InterfaceIndex" | select InterfaceIndex, IPv4DefaultGateway
                if(-not $ipConfigs -or $ipConfigs.Length -eq 0) 
                {
                    throw New-Object System.Exception("Failed to find the primary network interface")
                }
                $primaryIpConfig = $ipConfigs[0]
                $interfaceIndex = $primaryIpConfig.InterfaceIndex
                $defaultGateway = $primaryIpConfig.IPv4DefaultGateway.NextHop
                $interfaceMetric = 1
            }
            
            Write-Log "Primary network interface found. Adding routes now..."

            foreach ($ipAddr in $ipAddrs)
            {
                try
                {
                    Remove-NetRoute -DestinationPrefix $ipAddr -PolicyStore ActiveStore -Confirm:$false -ErrorAction SilentlyContinue
                    Remove-NetRoute -DestinationPrefix $ipAddr -PolicyStore PersistentStore -Confirm:$false -ErrorAction SilentlyContinue
                    New-NetRoute -DestinationPrefix $ipAddr -InterfaceIndex $interfaceIndex `
                        -NextHop $defaultGateway -RouteMetric $interfaceMetric -ErrorAction Stop
                    Write-Log ("Successfully added the Route: {0}, gateway: {1}, NIC index: {2}, Metric: {3}" `
                        -f $ipAddr, $defaultGateway, $interfaceIndex, $interfaceMetric)
                }
                catch
                {
                    Write-Log ("Failed to add routes: {0}" -f $ipAddr)
                }
            }
            
            # Break if routes are added successfully.
            break
        }
        catch
        {
            Write-Log ("Failed to add routes.. attempting it again {0}" -f $_.Exception.Message)
        }
        
        # It logs the status every 2 minutes.
        if (($count * $sleepTime) % 120 -eq 0) 
        { 
            Write-Log "Message: Failed to add routes.. attempting it again" -LogToConsole
        }

        Start-Sleep -seconds $sleepTime
        $count ++
    }
}
