# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-OSInfo sends OS, Version, ProductName, InstallOption, BuildLabEx, Language, TimeZone and Offset to console.
-------------------------------------------------------------------------------------------------------------#>
function Send-OSInfo
{
    Set-Variable windowInfoKey -Option Constant -Scope Local -Value "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    Set-Variable fullServer -Option Constant -Scope Local -Value "Full"
    Set-Variable nanoServer -Option Constant -Scope Local -Value "Nano"
    Set-Variable serverCore -Option Constant -Scope Local -Value "Server Core"
    Set-Variable serverOptions -Option Constant -Scope Local -Value @{ 0 = "Undefined"; 12 = $serverCore; 13 = $serverCore;
        14 = $serverCore; 29 = $serverCore; 39 = $serverCore; 40 = $serverCore; 41 = $serverCore; 43 = $serverCore;
        44 = $serverCore; 45 = $serverCore; 46 = $serverCore; 63 = $serverCore; 143 = $nanoServer; 144 = $nanoServer;
        147 = $serverCore; 148 = $serverCore; }

    try
    {
        $productName = ""
        $installOption = ""
        $osVersion = ""
        $osBuildLabEx = ""

        # Get ProductName and BuildLabEx from HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion
        if (Test-Path $windowInfoKey)
        {
            $windowInfo = Get-ItemProperty -Path $windowInfoKey
            $productName = $windowInfo.ProductName
            $osBuildLabEx = $windowInfo.BuildLabEx
            
            if ($windowInfo.CurrentMajorVersionNumber -and $windowInfo.CurrentMinorVersionNumber)
            {
                $osVersion = ("{0}.{1}" -f $windowInfo.CurrentMajorVersionNumber, $windowInfo.CurrentMinorVersionNumber)
            }
        }

        # Get Version and SKU from Win32_OperatingSystem 
        $osInfo = Get-CimInstance Win32_OperatingSystem | Select-Object Version, OperatingSystemSKU
        $osSkuNumber = [int]$osInfo.OperatingSystemSKU
        if (-not $osVersion -and $osInfo.Version)
        {
            $osVersionSplit = $osInfo.Version.Split(".")
            if ($osVersionSplit.Count -gt 1)
            {
                $osVersion = ("{0}.{1}" -f $osVersionSplit[0], $osVersionSplit[1])
            }
            elseif ($osVersionSplit.Count -eq 1)
            {
                $osVersion = ("{0}.0" -f $osVersionSplit[0])
            }
        }
        if ($serverOptions[$osSkuNumber]) 
        {
            $installOption = $serverOptions[$osSkuNumber]
        } 
        else 
        {
            $installOption = $fullServer
        }

        # Write the information to the console
        Write-Log ("OS: Microsoft Windows NT {0}" -f $osVersion) -LogToConsole
        Write-Log ("OsProductName: {0}" -f $productName) -LogToConsole
        Write-Log ("OsInstallOption: {0}" -f $installOption) -LogToConsole
        Write-Log ("OsVersion: {0}" -f $osVersion) -LogToConsole
        Write-Log ("OsBuildLabEx: {0}" -f $osBuildLabEx) -LogToConsole

        if(-not (Test-NanoServer))
        {
            Write-Log ("Language: {0}" -f ([CultureInfo]::CurrentCulture).IetfLanguageTag) -LogToConsole
        }
        else
        {            
            Write-Log ("Language: {0}" -f ([CultureInfo]::CurrentCulture).Name) -LogToConsole
        }

        Write-Log ("TimeZone: {0}" -f ([TimeZoneInfo]::Local).StandardName) -LogToConsole
        Write-Log ("Offset: UTC {0}" -f ([TimeZoneInfo]::Local).GetUtcOffset([DateTime]::Now)) -LogToConsole
    }
    catch
    {
        Write-Log "Unable to load OS build information" -LogToConsole
        Write-Log $_.Exception.Message
    }
}
