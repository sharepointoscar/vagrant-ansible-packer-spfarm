# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Set-Wallpaper sets the instance information on current wallpaper.
    If not wallpaper is set, it creates one with custom color.
-------------------------------------------------------------------------------------------------------------#>
function Set-Wallpaper
{
    param (
        [Parameter(Position=0)]
        [switch] $Initial
    )

    if (Test-NanoServer)
    {
        return
    }
    
    # Import the wallpaper util methods.
    Import-WallpaperUtil

    # Keep both original wallpaper and modified wallpaper in the following directories.
    $originalWallpaperPath = Join-Path $env:LOCALAPPDATA -ChildPath $script:originalWallpaperName
    $customWallpaperPath = Join-Path $env:LOCALAPPDATA -ChildPath $script:customWallpaperName
    
    # Get the current wallpaper path.
    $currentWallpaperPath = [WallpaperUtil.Helper]::GetWallpaper()

    # This is the initial wallpaper setting prepration at first time boot for the current user.
    if ($Initial)
    {
        # If wallpaper is still set to old custom wallpaper path, set it to original wallpaper.
        # This is a scenario for user profiles created before sysprep because Clear-Wallpaper
        # does not clear things for all users.
        if ($currentWallpaperPath -ieq $customWallpaperPath)
        {
            # If original wallpaper path exists, set the current wallpaper path to be it.
            # Otherwise, set the current wallpaper path to empty string.
            if (Test-Path $originalWallpaperPath)
            {
                $currentWallpaperPath = $originalWallpaperPath
            }
            else 
            {
                $currentWallpaperPath = ""
            }
        }
        else 
        {
            # If the current wallpaper path is under LOCALAPPDATA as Ec2Wallpaper, but not in the current user's path, copy the original wallpaper.
            if ((Test-Path $currentWallpaperPath) -and (Get-Item $currentWallpaperPath).Name -eq $script:customWallpaperName -and $currentWallpaperPath -ne $customWallpaperPath)
            {
                $temp = Join-Path (Get-Item $currentWallpaperPath).Directory.FullName -ChildPath $script:originalWallpaperName
                if (Test-Path $temp)
                {
                    $currentWallpaperPath = $temp
                }
                else 
                {
                    $currentWallpaperPath = ""
                }
            }

            # If the current wallpaper path is not the custom wallpaper path,
            # copy the original file to the current user's LOCALAPPDATA.
            Copy-Item -Path $currentWallpaperPath -Destination $originalWallpaperPath -Force
        }
    }
    else
    {
        # If this is not the initial wallpaper setting, check if the wallpaper has changed since the initial setting.
        if ($currentWallpaperPath -ne $customWallpaperPath)
        {
            # If wallpaper has changed after the initial setting by user, wallpaper setting is over.
            # Delete the wallpaper setup file in the current user's startup directory.
            $userStartupPath = "C:\Users\{0}\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -f $env:USERNAME
            $wallpaperSetupPath = Join-Path $userStartupPath -ChildPath $script:wallpaperSetupName

            if (Test-Path $wallpaperSetupPath)
            {
                Remove-Item -Path $wallpaperSetupPath -Force -Confirm:$false
            }

            if (Test-Path $customWallpaperPath)
            {
                # Also delete the custom wallpaper for the current user.
                Remove-Item -Path $customWallpaperPath -Force -Confirm:$false
            }

            # At the end, finish it.
            return
        }
    }

    # Some information is fetched from metadata.
    $metadata = @(  
        @{ Name="Instance ID"; Source="meta-data/instance-id" }
        @{ Name="Public IP Address"; Source="meta-data/public-ipv4" }
        @{ Name="Private IP Address"; Source="meta-data/local-ipv4" }
        @{ Name="Instance Size"; Source="meta-data/instance-type" }
        @{ Name="Availability Zone"; Source="meta-data/placement/availability-zone" }          
    )

    # These include all generations, both latest and older types.
    $instanceTypes = @( 
        @{ Type="t1.micro"; Memory="613 MB"; NetworkPerformance="Very Low" }
        @{ Type="t2.nano"; Memory="500 MB"; NetworkPerformance="Low to Moderate" }
        @{ Type="t2.micro"; Memory="1 GB"; NetworkPerformance="Low to Moderate" }
        @{ Type="t2.small"; Memory="2 GB"; NetworkPerformance="Low to Moderate" }
        @{ Type="t2.medium"; Memory="4 GB"; NetworkPerformance="Low to Moderate" }
        @{ Type="t2.large"; Memory="8 GB"; NetworkPerformance="Low to Moderate" }
        @{ Type="t2.xlarge"; Memory="16 GB"; NetworkPerformance="Moderate" }
        @{ Type="t2.2xlarge"; Memory="32 GB"; NetworkPerformance="Moderate" }
        @{ Type="m4.large"; Memory="8 GB"; NetworkPerformance="Moderate" }
        @{ Type="m4.xlarge"; Memory="16 GB"; NetworkPerformance="High" }
        @{ Type="m4.2xlarge"; Memory="32 GB"; NetworkPerformance="High" }
        @{ Type="m4.4xlarge"; Memory="64 GB"; NetworkPerformance="High" }
        @{ Type="m4.10xlarge"; Memory="160 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="m3.medium"; Memory="3.75 GB"; NetworkPerformance="Moderate" }
        @{ Type="m3.large"; Memory="7.5 GB"; NetworkPerformance="Moderate" }
        @{ Type="m3.xlarge"; Memory="15 GB"; NetworkPerformance="High" }
        @{ Type="m3.2xlarge"; Memory="30 GB"; NetworkPerformance="High" }
        @{ Type="m1.small"; Memory="1.7 GB"; NetworkPerformance="Low" }
        @{ Type="m1.medium"; Memory="3.7 GB"; NetworkPerformance="Moderate" }
        @{ Type="m1.large"; Memory="7.5 GB"; NetworkPerformance="Moderate" }
        @{ Type="m1.xlarge"; Memory="15 GB"; NetworkPerformance="High" }
        @{ Type="c4.large"; Memory="3.75 GB"; NetworkPerformance="Moderate" }
        @{ Type="c4.xlarge"; Memory="7.5 GB"; NetworkPerformance="High" }
        @{ Type="c4.2xlarge"; Memory="15 GB"; NetworkPerformance="High" }
        @{ Type="c4.4xlarge"; Memory="30 GB"; NetworkPerformance="High" }
        @{ Type="c4.8xlarge"; Memory="60 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="c3.large"; Memory="3.75 GB"; NetworkPerformance="Moderate" }
        @{ Type="c3.xlarge"; Memory="7.5 GB"; NetworkPerformance="Moderate" }
        @{ Type="c3.2xlarge"; Memory="15 GB"; NetworkPerformance="High" }
        @{ Type="c3.4xlarge"; Memory="30 GB"; NetworkPerformance="High" }
        @{ Type="c3.8xlarge"; Memory="60 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="c1.medium"; Memory="1.7 GB"; NetworkPerformance="Moderate" }
        @{ Type="c1.xlarge"; Memory="7 GB"; NetworkPerformance="High" }
        @{ Type="cc2.8xlarge"; Memory="60.5 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="cc1.4xlarge"; Memory="23 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="g2.2xlarge"; Memory="15 GB"; NetworkPerformance="High" }
        @{ Type="g2.8xlarge"; Memory="60 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="cg1.4xlarge"; Memory="22 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="r3.large"; Memory="15 GB"; NetworkPerformance="Moderate" }
        @{ Type="r3.xlarge"; Memory="30.5 GB"; NetworkPerformance="Moderate" }
        @{ Type="r3.2xlarge"; Memory="61 GB"; NetworkPerformance="High" }
        @{ Type="r3.4xlarge"; Memory="122 GB"; NetworkPerformance="High" }
        @{ Type="r3.8xlarge"; Memory="244 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="r4.large"; Memory="15.25 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="r4.xlarge"; Memory="30.5 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="r4.2xlarge"; Memory="61 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="r4.4xlarge"; Memory="122 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="r4.8xlarge"; Memory="244 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="r4.16large"; Memory="488 GB"; NetworkPerformance="20 Gigabit" }
        @{ Type="x1.16xlarge"; Memory="976 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="x1.32xlarge"; Memory="1952 GB"; NetworkPerformance="High" }
        @{ Type="m2.xlarge"; Memory="17.1 GB"; NetworkPerformance="Moderate" }
        @{ Type="m2.2xlarge"; Memory="34.2 GB"; NetworkPerformance="Moderate" }
        @{ Type="m2.4xlarge"; Memory="68.4 GB"; NetworkPerformance="High" }
        @{ Type="cr1.8xlarge"; Memory="244 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="d2.xlarge"; Memory="30.5 GB"; NetworkPerformance="Moderate" }
        @{ Type="d2.2xlarge"; Memory="61 GB"; NetworkPerformance="High" }
        @{ Type="d2.4xlarge"; Memory="122 GB"; NetworkPerformance="High" }
        @{ Type="d2.8xlarge"; Memory="244 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="i2.xlarge"; Memory="30.5 GB"; NetworkPerformance="Moderate" }
        @{ Type="i2.2xlarge"; Memory="61 GB"; NetworkPerformance="High" }
        @{ Type="i2.4xlarge"; Memory="122 GB"; NetworkPerformance="High" }
        @{ Type="i2.8xlarge"; Memory="244 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="i3.large"; Memory="15.25 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="i3.xlarge"; Memory="30.5 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="i3.2xlarge"; Memory="61 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="i3.4xlarge"; Memory="122 GB"; NetworkPerformance="Up to 10 Gigabit" }
        @{ Type="i3.8xlarge"; Memory="244 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="i3.16xlarge"; Memory="488 GB"; NetworkPerformance="20 Gigabit" }
        @{ Type="hi1.4xlarge"; Memory="60.5 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="hs1.8xlarge"; Memory="117 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="m4.16xlarge"; Memory="256 GB"; NetworkPerformance="20 Gigabit" }
        @{ Type="p2.xlarge"; Memory="61 GB"; NetworkPerformance="High" }
        @{ Type="p2.8xlarge"; Memory="488 GB"; NetworkPerformance="10 Gigabit" }
        @{ Type="p2.16xlarge"; Memory="732 GB"; NetworkPerformance="20 Gigabit" }
    )
    
    $infos = @()
    $instanceSize = ""
    
    # Before calling any function, initialize the log with filename
    Initialize-Log -Filename "WallpaperSetup.log"

    Write-Log "Setting up wallpaper begins"
    Write-Log "Getting instance information to render it on wallpaper"

    # Get current hostname.
    $infos += "Hostname: {0}" -f [System.Net.Dns]::GetHostName()

    # Get each information from metadata list defined above.
    foreach ($data in $metadata)
    {
        try 
        {
            $value = (Get-Metadata -UrlFragment $data.Source).Trim()
            $infos += "{0}: {1}" -f $data.Name, $value

            if ($data.Name -eq "Instance Size")
            {
                $instanceSize = $value
            }
            
            Write-Log ("Successfully retrieved {0} from metadata" -f $data.Name)
        } 
        catch 
        {
            Write-Log ("Failed to retrieve {0} from metadata: {1}" -f $data.Name, $_.Exception.Message)
        }
    }

    # Get architecture chip information from registry key.
    $envRegRes = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -ErrorAction SilentlyContinue
    if ($envRegRes -and $envRegRes.PROCESSOR_ARCHITECTURE)
    {
        $infos += "Architecture: {0}" -f $envRegRes.PROCESSOR_ARCHITECTURE
        Write-Log ("Successfully retrieved architecture chip from registry key" -f $data.Name)
    }
    else 
    {
        Write-Log "Failed to retrieve architecture chip from registry key"
    }

    # Set instance type information if instance size was found from metadata above
    if ($instanceSize)
    {
        $instanceType = $instanceTypes | Where-Object {$_.Type.Equals($instanceSize)}
        if ($instanceType)
        {
            $infos += "Total Memory: {0}" -f $instanceType.Memory
            $infos += "Network Performance: {0}" -f $instanceType.NetworkPerformance
            Write-Log ("Successfully found instance type information for instance size {0}" -f $instanceSize)
        }
        else
        {
            Write-Log ("Failed to find instance type information for instance size {0}" -f $instanceSize)
        }
    }

    # Check if message contains any information about the instance
    if ($infos.Length -eq 0)
    {
        throw New-Object System.Exception("Failed to get instance information.")
    }

    # Create a message from the infos
    $message = ""
    foreach ($info in $infos)
    {
        $message += $info + [Environment]::NewLine
    }

    Write-Log ("Successfully fetched instance information: {0}" -f $message)

    try
    {
        Add-Type -AssemblyName System.Windows.Forms

        $fontStyle = "Calibri"
        $fontSize = 12

        Write-Log "Rendering instance information on wallpaper"

        $width = [System.Windows.Forms.SystemInformation]::PrimaryMonitorSize.Width
        $height = [System.Windows.Forms.SystemInformation]::PrimaryMonitorSize.Height

        $textfont = New-object System.Drawing.Font($fontStyle, $fontSize, [System.Drawing.FontStyle]::Regular)
        $textBrush = New-Object Drawing.SolidBrush ([System.Drawing.Color]::White)
    
        $proposedSize = New-Object System.Drawing.Size([int]$width, [int]$height)
        $messageSize = [System.Windows.Forms.TextRenderer]::MeasureText($message, $textfont, $proposedSize)

        if (-not $currentWallpaperPath)
        {
            # Check and create a new wallpaper if no wallpaper is set in current system.
            Write-Log "No wallpaper is set.. Setting wallpaper with custom color"
            $bgrRectangle = New-Object Drawing.Rectangle(0, 0, [int]$width, [int]$height)
            $bgrBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Navy)
            $bmp = New-object System.Drawing.Bitmap([int]$width, [int]$height)
            $graphics = [System.Drawing.Graphics]::FromImage($bmp)
            $graphics.FillRectangle($bgrBrush, $bgrRectangle)
        }
        else
        {
            # Get the bitmap from the current wallpaper and set the size to be fit in screen.
            Write-Log "Wallpaper found.. Rendering instance information on current wallpaper"
            $srcBmp = [System.Drawing.Bitmap]::FromFile($originalWallpaperPath)
            $bmp = New-Object System.Drawing.Bitmap($srcBmp, $width, $height)
            $graphics = [System.Drawing.Graphics]::FromImage($bmp)
            $srcBmp.Dispose()
        }

        # Set the position and size of the text box with rectangle.
        $rec = New-Object System.Drawing.RectangleF(($width - $messageSize.Width - 20), 30, ($messageSize.Width + 20), $messageSize.Height)
        $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
        $graphics.DrawString($message, $textfont, $textBrush, $rec)

        # Save the new wallpaper in destination defined above.
        $bmp.Save($customWallpaperPath, [System.Drawing.Imaging.ImageFormat]::Jpeg)

        # Finally, set the wallpaper!
        [WallpaperUtil.Helper]::SetWallpaper($customWallpaperPath)

        Write-Log "Successfully rendered instance information on wallpaper"
    }
    catch 
    {
        Write-Log ("Failed to render instance information on wallpaper {0}" -f $_.Exception.Message)
    }
    finally
    {
        if ($graphics)
        {
            $graphics.Dispose()
        }
        if ($bmp)
        {
            $bmp.Dispose()
        }
    }
    
    # Before finishing the script, complete the log.
    Complete-Log
}