# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Invoke-Userdata retrieves and executes the userdata from metadata
    Currently, it supports powershell (+ with argument) and batch script.
-------------------------------------------------------------------------------------------------------------#>
function Invoke-Userdata
{     
    param (
        [Parameter(Mandatory=$false, Position=0)]
        [string] $Username,

        [Parameter(Mandatory=$false, Position=1)]
        [string] $Password,

        [Parameter(Mandatory=$false)]
        [switch] $OnlyUnregister,

        [Parameter(Mandatory=$false)]
        [switch] $FromPersist
    )
    
    # Before calling any function, initialize the log with filename
    Initialize-Log -Filename "UserdataExecution.log"
    
    try 
    {
        $scheduleName = "Userdata Execution"
        
        if ($OnlyUnregister) 
        {
            Register-FunctionScheduler -Function $MyInvocation.MyCommand -ScheduleName $scheduleName -Unregister
            return
        }

        Write-Log "Userdata execution begins"
        
        $regexFormat = "(?is){0}(.*?){1}"
        
        $powershellContent= ""
        $powershellArgs = ""
        $batchContent = ""

        $fileLocation = [System.IO.Path]::GetTempPath()

        $userdata = Get-Metadata -UrlFragment "user-data"
        if (-not $userdata)
        {
            # If no userdata is provided, unregister the scheduled task if scheduled before.
            Register-FunctionScheduler -Function $MyInvocation.MyCommand -ScheduleName $scheduleName -Unregister
            throw New-Object System.Exception("Userdata was not provided")
        }

        $userdataContent = $userdata.Trim()

        # Userdata is executed as local admin by default
        # But if password is empty, userdata is exeucted as local system by default
        $runAsLocalSystem = -not $Username -or -not $Password
        $persist = $false

        # Userdata can be persistent if <persist> tag is specified in userdata.
        # Parse persist from userdata and schedule a task if persist is true
        $persistRegex = [regex] ($regexFormat -f "<persist>", "</persist>")
        $persistMatch = $persistRegex.Matches($userdataContent)
        if ($persistMatch.Success -and $persistMatch.Captures.Count -eq 1 -and $persistMatch.Groups.Count -eq 2)
        {
            $persistValue = $persistMatch.Groups[1].Value
            Write-Log ("<persist> tag was provided: {0}" -f $persistValue)
            if ($persistValue -ieq "true")
            {
                Write-Log "Running userdata on every boot"
                $persist = $true
            }
        }
        else
        {
            Write-Log "Zero or more than one <persist> tag was not provided"
        }

        if ($persist)
        {
            Register-FunctionScheduler -Function $MyInvocation.MyCommand -Arguments "-FromPersist" -ScheduleName $scheduleName
        }
        else
        {
            Write-Log "Unregistering the persist scheduled task"            
            Register-FunctionScheduler -Function $MyInvocation.MyCommand -ScheduleName $scheduleName -Unregister
            if ($FromPersist) 
            {
                # If the function was called from scheduled task and persist tag is not found, don't execute it at all.
                return
            }
        }

        # Parse runAsLocalSystem from userdata
        $runAsLocalSystemRegex = [regex] ($regexFormat -f "<runAsLocalSystem>", "</runAsLocalSystem>")
        $runAsLocalSystemMatch = $runAsLocalSystemRegex.Matches($userdataContent)
        if ($runAsLocalSystemMatch.Success -and $runAsLocalSystemMatch.Captures.Count -eq 1 -and $runAsLocalSystemMatch.Groups.Count -eq 2)
        {
            $runAsLocalSystemValue = $runAsLocalSystemMatch.Groups[1].Value
            Write-Log ("<runAsLocalSystem> tag was provided: {0}" -f $runAsLocalSystemValue)
            if ($runAsLocalSystemValue -ieq "true")
            {
                Write-Log "Running userdata as local system"
                $runAsLocalSystem = $true
            }
        }
        else
        {
            Write-Log "Zero or more than one <runAsLocalSystem> tag was not provided"
        }

        # Parse script from userdata
        $scriptRegex = [regex] ($regexFormat -f "<script>", "</script>")
        $scriptMatch = $scriptRegex.Matches($userdataContent)
        if ($scriptMatch.Success -and $scriptMatch.Captures.Count -eq 1)
        {
            $batchContent = $scriptMatch.Groups[1].Value
        }
        else
        {
            Write-Log "Zero or more than one <script> tag was not provided"
        }
        
        # Parse powershell from userdata
        $powershellRegex = [regex] ($regexFormat -f "<powershell>", "</powershell>")
        $powershellMatch = $powershellRegex.Matches($userdataContent)
        if ($powershellMatch.Success -and $powershellMatch.Captures.Count -eq 1)
        {
            $powershellContent = $powershellMatch.Groups[1].Value
        }
        else
        {
            Write-Log "Zero or more than one <powershell> tag was not provided"
        }

        # Parse powershell arguments from userdata
        $powershellArgsRegex = [regex] ($regexFormat -f "<powershellArguments>", "</powershellArguments>")
        $powershellArgsMatch = $powershellArgsRegex.Matches($userdataContent)
        if ($powershellArgsMatch.Success -and $powershellArgsMatch.Captures.Count -eq 1)
        {
            $powershellArgs = $powershellArgsMatch.Groups[1].Value
        }
        else
        {
            Write-Log "Zero or more than one <powershellArguments> tag was not provided"
        }

        # Execute batch commands first
        if ($batchContent)
        {
            Write-Log "<script> tag was provided.. running script content"

            $userBatchFile = "UserScript.bat"

            # GetTempFileName method creates temp file in temp location. i.e. C:\Windows\TEMP\*.tmp
            $errorFile = [System.IO.Path]::GetTempFileName()
            $outputFile = [System.IO.Path]::GetTempFileName()
                
            $filePath = $fileLocation | Join-Path -ChildPath $userBatchFile
            $batchContent | Out-File $filePath -Encoding ascii

            if ($runAsLocalSystem)
            {
                Start-Process $script:cmdPath -ArgumentList  "/C", `"$filePath`" -Wait -NoNewWindow -RedirectStandardOutput $outputFile -RedirectStandardError $errorFile
            }
            else
            {
                Invoke-CmdAsAdmin -Username $Username -Password $Password -Command "$script:cmdPath /C `"`"$filePath`" 1> `"$outputFile`" 2> `"$errorFile`"`""
            }

            $output = Get-Content $errorFile -Raw
            if ($output)
            {
                Write-Log ("Message: The errors from user scripts: {0}" -f $output)
            }

            $output = Get-Content $outputFile -Raw
            if ($output)
            {
                Write-Log ("Message: The output from user scripts: {0}" -f $output)
            }
        }

        # Execute powershell commands
        if ($powershellContent)
        {
            Write-Log "<powershell> tag was provided.. running powershell content"

            $userPowershellFile = "UserScript.ps1"

            # GetTempFileName method creates temp file in temp location. i.e. C:\Windows\TEMP\*.tmp
            $errorFile = [System.IO.Path]::GetTempFileName()
            $outputFile = [System.IO.Path]::GetTempFileName()
                
            $filePath = $fileLocation | Join-Path -ChildPath $userPowershellFile
            $powershellContent | Out-File $filePath

            if (-not $powershellArgs)
            {
                # If argument is provided, we let user to define the entire argument portion
                # But if argument is not provided, argument is set for execution policy 
                $powershellArgs = "-ExecutionPolicy Unrestricted"
            }
                
            if ($runAsLocalSystem)
            {
                Start-Process $script:psPath -ArgumentList $powershellArgs, ".", `"$filePath`" -Wait -NoNewWindow -RedirectStandardOutput $outputFile -RedirectStandardError $errorFile
            }
            else 
            {
                Invoke-CmdAsAdmin -Username $Username -Password $Password -Command "$script:cmdPath /C `"$script:psPath $powershellArgs . `"$filePath`" 1> `"$outputFile`" 2> `"$errorFile`"`""
            }

            $output = Get-Content $errorFile -Raw
            if ($output)
            {
                Write-Log ("Message: The errors from user scripts: {0}" -f $output)
            }

            $output = Get-Content $outputFile -Raw
            if ($output)
            {
                Write-Log ("Message: The output from user scripts: {0}" -f $output)
            }
        }

    }
    catch 
    {
        Write-Log ("Unable to execute userdata: {0}" -f $_.Exception.Message)
    }
    finally
    {
        $Password = ""
    }

    Write-Log "Userdata execution done"

    # Before finishing the script, complete the log.
    Complete-Log
}