# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Wait-Metadata repeatedly attempts to get metadata.
    Many tasks use the metadata, so it is important to wait for metadata.
-------------------------------------------------------------------------------------------------------------#>
function Wait-Metadata
{
    Write-Log "Message: Waiting for meta-data accessibility..." -LogToConsole
    
    $sleepTime = 5
    $count = 0

    while ($true) 
    {
        try 
        {
            # If getting metadata doesn't throw an exception, it is available.
            Get-Metadata -UrlFragment "meta-data/" | Out-Null
            Write-Log "Message: Meta-data is now available." -LogToConsole
            break
        } 
        catch 
        {
            Write-Log ("Failed to load metadata {0}" -f $_.Exception.Message)
        }

        # It logs the status to console every 2 minutes.
        if (($count * $sleepTime) % 120 -eq 0) 
        { 
            Write-Log "Message: Still waiting for meta-data accessibility..." -LogToConsole
        }

        Start-Sleep -seconds $sleepTime
        $count ++
    }
}
