# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Get-LaunchConfig opens Config/LaunchConfig.json and reads configurations.
-------------------------------------------------------------------------------------------------------------#>
function Get-LaunchConfig
{ 
    param (
        [Parameter(Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [ValidateSet("SetComputerName", "SetWallpaper", "AddDnsSuffixList", "ExtendBootVolumeSize", "AdminPasswordType", "AdminPassword")]
        [string] $Key,

        # Delete switch indicates that key's attribute value should be deleted after it's read from config.
        [Parameter(Mandatory=$false)]
        [switch] $Delete
    )

    # These are constant values for AdminPasswordType.
    Set-Variable randomPassword -Option Constant -Value "Random"
    Set-Variable specifyPassword -Option Constant -Value "Specify"

    $launchConfigPath = Join-Path $script:configPath -ChildPath "LaunchConfig.json"

    # If launch config mapping is set, return the value from the mapping.
    if (-not $script:launchConfig)
    {

        # Otherwise, continue to read launch config from file.
        Write-Log "Reading launch config from file"

        # Create a launch config mapping in script scope with default values.
        Set-Variable launchConfig -Scope Script

        # Attempt to get the configs from Config\LaunchConfig.json.
        try
        {
            if (-not (Test-Path $launchConfigPath))
            {
                throw New-Object System.Exception("{0} not found" -f $launchConfigPath)
            }

            $content = Get-Content $launchConfigPath -Raw
            $json = $content | ConvertFrom-Json
            $json | Confirm-LaunchConfig -ErrorAction:Stop | Out-Null

            $script:launchConfig = [ordered]@{
                SetComputerName = $json.setComputerName
                SetWallpaper = $json.setWallpaper
                AddDnsSuffixList = $json.addDnsSuffixList
                ExtendBootVolumeSize = $json.extendBootVolumeSize
                AdminPasswordType = $json.adminPasswordType
                AdminPassword = $json.adminPassword
            }
        }
        catch
        {
            $script:launchConfig = @()
            Write-Log ("Failed to read launch config: {0} " -f $_.Exception.Message)
        }

        # If it fails to read launch config, create a mapping with default values.
        if (-not $script:launchConfig)
        {
            Write-Log "Using default config values"
            $script:launchConfig = [ordered]@{
                SetComputerName = $false;
                SetWallpaper = $true;
                AddDnsSuffixList = $true;
                ExtendBootVolumeSize = $true;
                AdminPasswordType = $randomPassword;
                AdminPassword = "";
            }
        }

        # Log the launch config mapping to inform users with detail.
        $message = "Finished reading launch configs: {0}" -f [Environment]::NewLine
        $configKeys = $script:launchConfig.Keys
        foreach ($configKey in $configKeys)
        {
            if ($configKey -ine "AdminPassword") 
            {
                $message += "{0}: {1}{2}" -f $configKey, $script:launchConfig[$configKey], [System.Environment]::NewLine
            }
        }

        Write-Log $message
    }

    if ($Delete)
    {
        # Empty the attribute value and store it into launch config file.
        $result = $script:launchConfig[$Key]
        $script:launchConfig[$Key] = ""
        $script:launchConfig | ConvertTo-Json | Set-Content $launchConfigPath 
        return $result
    }
    else
    {
        return $script:launchConfig[$Key]
    }
}
