# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Clear-Wallpaper clears the customized wallpaper
-------------------------------------------------------------------------------------------------------------#>
function Clear-Wallpaper
{
    try 
    {
        # Import wallpaper pinvoke functions
        Import-WallpaperUtil

        $currentWallpaperPath = [WallpaperUtil.Helper]::GetWallpaper()
        $originalWallpaperPath = Join-Path $env:LOCALAPPDATA -ChildPath $script:originalWallpaperName
        $customWallpaperPath = Join-Path $env:LOCALAPPDATA -ChildPath $script:customWallpaperName

        # If wallpaper is set with custom wallpaper, set it with original wallpaper
        if ($currentWallpaperPath -ieq $customWallpaperPath)
        {
            [WallpaperUtil.Helper]::SetWallpaper($originalWallpaperPath)
        }

        # Custom wallpaper is removed if it exists.
        if (Test-Path $customWallpaperPath)
        {
            Remove-Item -Path $customWallpaperPath -Force -Confirm:$false
        }

        # Remove wallpapers copied to default profile
        $defaultLocalPath = "C:\Users\Default\AppData\Local"
        $defaultLocalCustomWallpaperPath = Join-Path $defaultLocalPath -ChildPath $script:customWallpaperName
        if (Test-Path $defaultLocalCustomWallpaperPath)
        {
            Remove-Item $defaultLocalCustomWallpaperPath -Force -Confirm:$false
        }
        
        # Remove legacy wallpaper setup files created with version below v1.1.2
        $legacyStartupPath = Join-Path $env:ProgramData -ChildPath "Microsoft\Windows\Start Menu\Programs\StartUp"
        $legacyInitWallpaperSetupPath = Join-Path $legacyStartupPath -ChildPath $script:initWallpaperSetupName
        $legacyWallpaperSetupPath = Join-Path $legacyStartupPath -ChildPath $script:wallpaperSetupName
        if (Test-Path $legacyInitWallpaperSetupPath)
        {
            Remove-Item $legacyInitWallpaperSetupPath -Force -Confirm:$false
        }
        if (Test-Path $legacyWallpaperSetupPath)
        {
            Remove-Item $legacyWallpaperSetupPath -Force -Confirm:$false
        }
        
        # Remove the wallpaper setup files from all user's startup directory
        foreach ($userDir in (Get-ChildItem "C:\Users" -Force -Directory).FullName)
        {
            $startupPath = Join-Path $userDir -ChildPath "AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
            if (Test-Path $startupPath)
            {
                $initWallpaperSetupPath = Join-Path $startupPath -ChildPath $script:initWallpaperSetupName
                $wallpaperSetupPath = Join-Path $startupPath -ChildPath $script:wallpaperSetupName
                if (Test-Path $initWallpaperSetupPath)
                {
                    Remove-Item $initWallpaperSetupPath -Force -Confirm:$false
                }
                if (Test-Path $wallpaperSetupPath)
                {
                    Remove-Item $wallpaperSetupPath -Force -Confirm:$false
                }
            }
        }
    }
    catch
    {
        Write-Log ("Failed to clear the wallpaper: {0}" -f $_.Exception.Message)
    }
}