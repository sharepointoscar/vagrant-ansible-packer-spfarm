# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Test-EphemeralDisk
{
    param (
        [parameter(Mandatory=$false)]
        [int] $DiskIndex,

        [parameter(Mandatory=$false)]
        [int] $DiskSCSITargetId
    )

    $isEphemeral = $false
    
    try
    {
        # Special check: NVMe disk is mounted before boot volume and always contains SCSITargetId 0.
        # So, DiskIndex and DiskSCSITargetId are not sufficient to identify NVMe disks. 
        # Instead, it checks whether PNPDeviceId string contains NVME.
        $disk = Get-CimInstance -ClassName Win32_DiskDrive | Where-Object { $_.Index -eq $DiskIndex }
        if ($disk.PNPDeviceId -like "*NVME*")
        {
            return $true
        }

        if (-not $script:blockDriveMapping)
        {
            # BlockDriveMapping mapping is used to find if each drive is ephemeral or non-ephemeral.
            Set-Variable blockDriveMapping -Scope Script -Value (Get-BlockDriveMapping)

            if ($script:blockDriveMapping.Length -eq 0)
            {
                throw New-Object System.InvalidOperationException("Could not get the block drive mapping info from metadata")
            }
        }

        # This is to determine whether disk is ephemeral, which needs to be labeled as temporary storage.
        # BlockDeviceMapping from metadata is used to find this info.
        # But it is only applicable if the system is using Citrix PV Driver.
        $driveName = ""

        if ($DiskIndex -eq 0)
        {
            $driveName = "/dev/sda1"
        }
        else
        {
            $driveName = "xvd"
            $offset = $DiskSCSITargetId

            if ($DiskSCSITargetId -gt 25)
            {
                $math = [Int][Math]::Floor($DiskSCSITargetId / 26)
                $offset = $DiskSCSITargetId - (26 * $math)
                $driveName += [Char] (97 + ($math - 1))
            }

            $driveName += [Char] (97 + $offset)
        }

        $matchingBlockDrive = $script:blockDriveMapping | where { $_.MountPoint -eq $driveName }
        if ($matchingBlockDrive.Length -ne 0) 
        {
            $isEphemeral = $matchingBlockDrive[0].IsEphemeral
        }
    }
    catch
    {
        Write-Log ("Failed to test ephemeral disk: {0}" -f $_.Exception.Message)
    }

    return $isEphemeral
}