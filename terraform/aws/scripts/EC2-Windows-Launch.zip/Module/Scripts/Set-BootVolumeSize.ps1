# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Set-BootVolumeSize extends the boot volume size with unallocated spaces
-------------------------------------------------------------------------------------------------------------#>
function Set-BootVolumeSize
{
    $state = Get-LaunchConfig -Key ExtendBootVolumeSize
    if (-not $state)
    {
        Write-Log "Extending boot volume size is disabled"
        return
    }

    try 
    {
        Write-Log "Executing boot volume extension"

        if (-not (Test-NanoServer))
        {
            "Select Disk 0", "Select Volume C", "Extend" | diskpart
        }
        else
        {
            $maxSize = (Get-PartitionSupportedSize -DriveLetter c).sizeMax
            Resize-Partition -DriveLetter c -Size $maxSize -ErrorAction SilentlyContinue
        }
        Write-Log "Finish executing boot volume extension"
    } 
    catch 
    {
        Write-Log ("Resize partition returned error while extending the disk: {0}" -f $_.Exception.Message)
    }
}
