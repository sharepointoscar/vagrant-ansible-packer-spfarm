# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    New-WallpaperSetup creates wallpaper setup cmd in windows startup directory and return.
-------------------------------------------------------------------------------------------------------------#>
function New-WallpaperSetup
{
    if (Test-NanoServer)
    {
        return
    }
    
    # Return if SetWallpaper task is disabled.
    $state = Get-LaunchConfig -Key SetWallpaper
    if (-not $state)
    {
        Write-Log "Setting wallpaper name is disabled"
        Clear-Wallpaper
        return
    }

    Write-Log "Creating wallpaper setup cmd in startup directory"

    # Create some commands that render instance information on current wallpaper and save it as cmd in startup directory.
    $content = "@Echo Off"
    $content += [System.Environment]::NewLine + "REM Render instance information on current wallpaper if this is the wallpaper was never changed by user."
    $content += [System.Environment]::NewLine + "{0} -NoProfile -NonInteractive -NoLogo -WindowStyle hidden -ExecutionPolicy Unrestricted `"Import-Module `"{1}`"; Set-Wallpaper -Initial`" & REM DELETEME" -f $script:psPath, $script:moduleFilePath 
    $content += [System.Environment]::NewLine + "type `"%~f0`" | findstr /v DELETEME > `"%~dp0$script:wallpaperSetupName`""
    $content += [System.Environment]::NewLine + "DEL /Q /F `"%~f0`" & REM DELETEME"
    $content += [System.Environment]::NewLine + "GOTO :EOF & REM DELETEME"
    $content += [System.Environment]::NewLine + "{0} -NoProfile -NonInteractive -NoLogo -WindowStyle hidden -ExecutionPolicy Unrestricted `"Import-Module `"{1}`"; Set-Wallpaper`"" -f $script:psPath, $script:moduleFilePath

    try
    {
        # Create the wallpaper setup batch file in all user's startup directory
        foreach ($userDir in (Get-ChildItem "C:\Users" -Force -Directory).FullName)
        {
            # Create the wallpaper setup batch file if startup directory exists 
            $startupPath = Join-Path $userDir -ChildPath "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
            if (Test-Path $startupPath)
            {
                $initWallpaperSetupPath = Join-Path $startupPath -ChildPath $script:initWallpaperSetupName
                New-Item -Path $initWallpaperSetupPath -ItemType File -Value $content -Force | Out-Null
            }
        }
    }
    catch
    {
        Write-Log ("Failed to render instance information on wallpaper {0}" -f $_.Exception.Message)
    }
}