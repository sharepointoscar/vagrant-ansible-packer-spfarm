# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Get-DriveLetterMappingConfig
{ 
    Write-Log "Reading drive letter mapping config from file"

    # Create a drive letter mapping.
    $driveLetterMappings = @()
    
    # Attempt to get the configs from Config\LaunchConfig.json.
    try
    {
        $driveLetterMappingConfigPath = (Join-Path -Path $script:ConfigPath -ChildPath "DriveLetterMappingConfig.json")
        if (-not (Test-Path $driveLetterMappingConfigPath))
        {
            throw New-Object System.Exception("{0} not found" -f $driveLetterMappingConfigPath)
        }

        $content = Get-Content $driveLetterMappingConfigPath -Raw
        $json = $content | ConvertFrom-Json

        if (-not $json.driveLetterMapping)
        {
            throw New-Object System.Exception("Failed to find driverLetterMapping attritube in config file")
        }

        foreach ($driveLetterMapping in $json.driveLetterMapping)
        {
            $newDriveLetterMapping = new-object PSObject
            $newDriveLetterMapping | add-member -type NoteProperty -Name VolumeName -Value ($driveLetterMapping.volumeName)
            $newDriveLetterMapping | add-member -type NoteProperty -Name DriveLetter -Value ($driveLetterMapping.driveLetter)
            $driveLetterMappings += $newDriveLetterMapping
        }
    }
    catch
    {
        Write-Log ("Failed to read drive letter mapping config: {0} " -f $_.Exception.Message)
    }

    # Log the drive letter mapping to inform users with detail.
    $message = "Finished reading drive letter mapping config:{0}" -f [Environment]::NewLine
    foreach ($driveLetterMapping in $driveLetterMappings)
    {
        $message += "Volume Name: {0}; Drive Letter: {1}{2}" -f $driveLetterMapping.VolumeName, $driveLetterMapping.DriveLetter, [System.Environment]::NewLine
    }

    Write-Log $message
    
    return $driveLetterMappings
}
