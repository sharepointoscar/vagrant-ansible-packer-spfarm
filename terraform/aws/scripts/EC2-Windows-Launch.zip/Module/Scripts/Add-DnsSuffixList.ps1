# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Add-DnsSuffixList adds DNS suffixes.
-------------------------------------------------------------------------------------------------------------#>
function Add-DnsSuffixList
{
    $state = Get-LaunchConfig -Key AddDnsSuffixList
    if (-not $state) 
    {
        Write-Log "Adding DNS suffix list is disabled"
        return
    }

    $suffixList = @()

    Write-Log ("Adding DNS suffixes in search list begins")
    
    # Try to create a suffix with available zone
    try
    {
        # Availability-zone includes period at the end, so it needs to remove it.
        $availabilityZone = (Get-Metadata -UrlFragment "meta-data/placement/availability-zone").Trim()
        if ($availabilityZone.EndsWith(".")) 
        {
            $availabilityZone = $availabilityZone.Substring(0, $availabilityZone.Length-1)
        }

        $suffixList += "{0}.ec2-utilities.amazonaws.com" -f $availabilityZone.Substring(0, $availabilityZone.Length-1)
    }
    catch
    {
        Write-Log ("Failed to get availability zone: {0}" -f $_.Exception.Message)
    }

    # Try to get global search list
    try 
    {
        $tcpRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
        $tcpRegRes = Get-ItemProperty -Path $tcpRegPath
        $existingList = $tcpRegRes.SearchList -split ","
        foreach ($existing in $existingList)
        {
            if ($existing -and $suffixList -notcontains $existing)
            {
                $suffixList += $existing.ToLower()
            }
        }
    }
    catch
    {
        Write-Log ("Failed to get global search list: {0}" -f $_.Exception.Message)
    }

    # Try to get DNS Domain
    try
    {
        $dnsDomain = $tcpRegRes.Domain
        if ($dnsDomain -and $suffixList -notcontains $dnsDomain)
        {
            $suffixList += $dnsDomain.ToLower()
        }
        $isUsingDomainDevolution = $tcpRegRes.UseDomainNameDevolution
        if ($isUsingDomainDevolution -ne 0)
        {
            $dnsDomains = $dnsDomain -split "\."
            if ($dnsDomains.Length -gt 2)
            {
                $dns = $dnsDomains.Get($dnsDomains.Length - 1)
                for($i=$dnsDomains.Length - 2; $i -ge 1; $i--)
                {
                    $dns = "{0}.{1}" -f $dnsDomains.Get($i), $dns
                    if ($dns -and $suffixList -notcontains $dns)
                    {
                        $suffixList += $dns.ToLower()
                    }
                }
            }
        }
    }    
    catch
    {
        Write-Log ("Failed to get DNS domain from registry: {0}" -f $_.Exception.Message)
    }

    # Try to get NV Domain - contains computer's primary DNS suffix
    try
    {
        $nvDomain = $tcpRegRes."NV Domain"
        if ($nvDomain -and $suffixList -notcontains $nvDomain)
        {
            $suffixList += $nvDomain.ToLower()
        }
    }
    catch
    {
        Write-Log ("Failed to get NV domain: {0}" -f $_.Exception.Message)
    }
    
    # Try to get DNS Domain from connected NICs
    try
    {
        $networkAdapters = Get-CimInstance -ClassName Win32_NetworkAdapter
        foreach ($networkAdapter in $networkAdapters)
        {
            # Check each NIC if it is connected (Connected = 2)
            if ($networkAdapter.NetConnectionStatus -eq 2)
            {
                $networkConfig = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "Index='$($networkAdapter.Index)'"
                $nicDnsDomain = $networkConfig.DNSDomain
                if ($nicDnsDomain -and $suffixList -notcontains $nicDnsDomain)
                {
                    $suffixList += $nicDnsDomain.ToLower()
                }
            }
        }
    }    
    catch
    {
        Write-Log ("Failed to get DNS domain from NICs: {0}" -f $_.Exception.Message)
    }

    try
    {
        # Set DNS suffix search list
        Invoke-CimMethod -ClassName Win32_NetworkAdapterConfiguration -MethodName "SetDNSSuffixSearchOrder" -Arguments @{ DNSDomainSuffixSearchOrder = $suffixList } | Out-Null
    }
    catch
    {
        Write-Log ("Failed to set DNS suffix search list: {0}" -f $_.Exception.Message)
    }

    Write-Log ("Adding DNS suffixes in search list done")  
}
