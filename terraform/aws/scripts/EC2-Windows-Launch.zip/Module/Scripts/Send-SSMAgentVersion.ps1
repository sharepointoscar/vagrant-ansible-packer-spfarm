# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-SSMAgentVersion sends SSM Agent version to console.
-------------------------------------------------------------------------------------------------------------#>
function Send-SSMAgentVersion 
{
    try 
    {
        Set-Variable serviceRegKey -Option Constant -Scope Local -Value "HKLM:\SYSTEM\CurrentControlSet\Services\AmazonSSMAgent"
        Set-Variable uninstallRegKey -Option Constant -Scope Local -Value "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{B1A3AC35-A431-4C8C-9D21-E2CA92047F76}"

        $version = ""

        # Check if the 
        if (Test-Path $serviceRegKey) 
        {
            $service = Get-ItemProperty -Path $serviceRegKey -ErrorAction SilentlyContinue
            $version = $service.Version
        }

        if (-not $version -and (Test-Path $uninstallRegKey)) 
        {
            $service = Get-ItemProperty -Path $uninstallRegKey -ErrorAction SilentlyContinue
            $version = $service.DisplayVersion
        }

        if ($version) 
        {
            Write-Log ("SSM: Amazon SSM Agent v{0}" -f $version) -LogToConsole
        }
    }
    catch
    {
        Write-Log ("Failed to send SSMAgent version: {0}" -f $_.Exception.Message)
    }
}