# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Set-DriveLetters
{
    $driveLetterMappings = Get-DriveLetterMappingConfig
    if (-not $driveLetterMappings)
    {
        Write-Log "Could not find the drive letter mapping config or it is empty"
        return
    }

    foreach ($driveLetterMapping in $driveLetterMappings)
    {
        $volumeName = $driveLetterMapping.VolumeName
        $newDriveLetter = $driveLetterMapping.DriveLetter
        
        # Verify if the given drive letter is valid.
        if ($newDriveLetter.Length -ne 1)
        {
            Write-Log ("Invalid drive letter '{0}'.. skipping it" -f $newDriveLetter)
            continue
        }

        # Get the disk with given volume name.
        $disk = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "VolumeName='$volumeName'"
        if (-not $disk -or -not $disk.Name)
        {
            Write-Log ("Volume name `"{0}`" doesn't exist.. skipping it" -f $volumeName)
            continue
        }

        # Get the current drive letter of the volume.
        $currentDriveLetter = $disk.Name
        if ($currentDriveLetter -and $currentDriveLetter.EndsWith(":"))
        {
            $currentDriveLetter = $currentDriveLetter.TrimEnd(":")
        }
            
        # Verify if the current drive letter of the volume is not same as new drive letter.
        if ($currentDriveLetter -ieq $newDriveLetter)
        {
            Write-Log ("Volume `"{0}`" already has the drive letter '{1}'.. skipping it" -f $volumeName, $newDriveLetter)
            continue
        }
            
        # Verify if the drive letter is not taken by another disk.
        if (Get-PSDrive -Name $newDriveLetter -ErrorAction SilentlyContinue)
        {
            Write-Log ("Drive letter '{0}' is already taken by another disk.. skipping it" -f $newDriveLetter)
            continue
        }

        try
        {
            Write-Log ("Changing '{0}' to '{1}' for volume `"{2}`"" -f $currentDriveLetter, $newDriveLetter, $volumeName)
            # Finally, set the volume with new drive letter.
            Set-Partition -DriveLetter $currentDriveLetter -NewDriveLetter $newDriveLetter
        }
        catch
        {
            Write-Log ("Failed to set volume `"{0}`" with new drive letter '{1}': {2}" -f $volumeName, $newDriveLetter, $_.Exception.Message)
        }
    }
}