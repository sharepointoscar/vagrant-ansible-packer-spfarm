# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-Message opens COM port and writes the message to console
-------------------------------------------------------------------------------------------------------------#>
function Send-Message
{
    param (
        # Message is a mandatory argument.
        [Parameter(Mandatory=$true, Position=0)]
        [string] $Message
    )

    # If these script variables are already set, message can be written to the stream with no longer setup.
    if (($script:spFileHandle -eq [System.IntPtr]::Zero) -or (-not $script:spSafeFileHandle) -or (-not $script:spStream))
    {
        Write-Log "Failed to write to console: open serial port using Open-SerialPort"
    }
    
    # Meesage needs to be appended with a new line and kept in bytes to be written in stream.
    $messageBytes = [System.Text.Encoding]::UTF8.GetBytes($Message + [System.Environment]::NewLine)
    $script:spStream.Write($messageBytes, 0, $messageBytes.Length)
}
