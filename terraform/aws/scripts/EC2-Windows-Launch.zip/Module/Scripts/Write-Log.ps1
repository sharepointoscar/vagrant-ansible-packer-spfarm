# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Write-Log logs given message to file and console if the argument is provided.
-------------------------------------------------------------------------------------------------------------#>
function Write-Log
{
    param (
        # Message is a mandatory argument.
        [Parameter(Mandatory=$true, Position=0)]
        [string] $Message,

        # LogToConsole is to log the message to both file and console.
        [Parameter(Mandatory=$false)]
        [switch] $LogToConsole = $false
    )

    # Initialize-Log function must be called first prior to calling this function.
    if (-not $script:logSettingStack -or $script:logSettingStack.Count -eq 0)
    {
        return
    }

    $logSetting = $script:logSettingStack.Peek()
    $logFilename = $logSetting.LogFilename
    $allowLogToConsole = $logSetting.AllowLogToConsole

    # Set log file path with log filename set by Initialize-Log.
    if (-not (Test-Path $script:logPath))
    {
       New-Item -Path $script:logPath -Type directory | Out-Null
    }
    $filePath = Join-Path $script:logPath -ChildPath $logFilename
    if (-not (Test-Path $filePath))
    {
        New-Item -Path $filePath -Type file | Out-Null
    }

    # Every message must include a timestamp in the following format.
    try
    {
        $newMessage = "{0}: {1}" -f (Get-Date).ToUniversalTime().ToString("yyyy'/'MM'/'dd HH':'mm':'ss'Z'"), $Message
        $newMessage | Out-File -Filepath $filePath -Append
    }
    catch 
    {

    }

    # If LogToConsole is allowed and is provided, it displays the message to console.
    if ($allowLogToConsole -and $LogToConsole)
    {    
        try
        {
            # Open COM port and write message to console
            Send-Message -Message $newMessage
        } 
        catch 
        {
            Write-Log ("Failed to log to console: {0}" -f $_.Exception)
        }
    }
}
