# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Set-Trim
{
    param (
        [parameter(Mandatory=$false)]
        [bool] $Enable
    )
    
    $output = fsutil behavior query DisableDeleteNotify NTFS
    $wasTrimEnabled = $output.Contains("DisableDeleteNotify = 0")

    if ($Enable)
    {
        Write-Log "Enable TRIM"
        fsutil behavior set DisableDeleteNotify NTFS 0 | Out-Null
    }
    else 
    {
        Write-Log "Disable TRIM"
        fsutil behavior set DisableDeleteNotify NTFS 1 | Out-Null
    }

    return $wasTrimEnabled
}