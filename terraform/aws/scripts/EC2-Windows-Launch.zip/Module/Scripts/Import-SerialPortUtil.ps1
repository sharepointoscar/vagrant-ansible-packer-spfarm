# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function Import-SerialPortUtil 
{
    try
    {
        # Check if type is already added.
        $check = [SerialPortUtil]
    }
    catch 
    {
        Add-Type -TypeDefinition @'
            using System;
            using System.Runtime.InteropServices;

            namespace SerialPortUtil {
         
                [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
                public struct Dcb {
                    public uint DcbLength;
                    public uint BaudRate;
                    public uint BinaryFlag;
                    public uint ParityFlag;
                    public uint OutxCtsFlowFlag;
                    public uint OutxDsrFlowFlag;
                    public uint DtrControlFlag;
                    public uint DsrSensitivityFlag;
                    public uint TXContinueOnXoffFlag;
                    public uint OutXFlag;
                    public uint InXFlag;
                    public uint ErrorCharFlag;
                    public uint NullFlag;
                    public uint RtsControlFlag;
                    public uint AbortOnErrorFlag;
                    public uint DummyFlag2;
                    public ushort Reserved;
                    public ushort XonLim;
                    public ushort XoffLim;
                    public byte ByteSize;
                    public byte Parity;
                    public byte StopBits;
                    public sbyte XonChar;
                    public sbyte XoffChar;
                    public sbyte ErrorChar;
                    public sbyte EofChar;
                    public sbyte EvtChar;
                    public ushort Reserved1;
                }

                public static class PInvoke {

                    [DllImport("KernelBase.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern IntPtr CreateFile(
                        string lpFileName,
                        uint dwDesiredAccess,
                        uint dwShareMode,
                        IntPtr lpSecurityAttributes,
                        uint dwCreationDisposition,
                        uint dwFlagsAndAttributes,
                        IntPtr hTemplateFile
                    );

                    [DllImport("KernelBase.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool SetCommState(IntPtr hFile, ref Dcb lpDCB);
    
                    [DllImport("KernelBase.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool GetCommState(IntPtr hFile, ref Dcb lpDCB);
    

                    [DllImport("KernelBase.dll", SetLastError=true, CharSet=CharSet.Unicode)]
                    public static extern bool CloseHandle(IntPtr handle);

                }
            }
'@
    }       
}
