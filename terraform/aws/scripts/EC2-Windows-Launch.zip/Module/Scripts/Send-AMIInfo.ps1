# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Send-AMIInfo sends AMI Origin Version and Name to console.
-------------------------------------------------------------------------------------------------------------#>
function Send-AMIInfo
{
    try
    {
        $machineImageKey = "HKLM:\SOFTWARE\Amazon\MachineImage"
        if (Test-Path $machineImageKey)
        {
            $machineImage = Get-ItemProperty -Path $machineImageKey
            Write-Log ("AMI Origin Version: {0}" -f $machineImage.AMIVersion) -LogToConsole
            Write-Log ("AMI Origin Name: {0}" -f $machineImage.AMIName) -LogToConsole
        }
        else
        {
            throw New-Object System.Exception("`"{0}`" is missing in registry" -f $machineImageKey)
        }
    }
    catch
    {
        Write-Log "Unable to load AMI information" -LogToConsole
        Write-Log $_.Exception.Message
    }
}