# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Register-ScriptScheduler registers a scheduled task to execute a script on next boot.
-------------------------------------------------------------------------------------------------------------#>
function Register-ScriptScheduler
{
    param (
        # this argument must be provided to check and set serial port before starting tasks
        [parameter(Mandatory=$true, Position=0)]
        [string] $ScriptPath, 

        [parameter(Mandatory=$false, Position=1)]
        [string] $Arguments,

        [parameter(Mandatory=$true, Position=2)]
        [string] $ScheduleName,

        # This argument ensures the task to be unregistered.
        [parameter(Mandatory=$false)]
        [switch] $Unregister = $false,
        
        [parameter(Mandatory=$false)]
        [switch] $Disabled = $false
    )
    
    try
    {
        # Script must be exeucted with -NoProfile to reduce the execution delay and -ExecutionPolicy Unrestricted to grant the permission.
        $psCommand = "/C {0} -NoProfile -NonInteractive -NoLogo -ExecutionPolicy Unrestricted -File `"{1}`" {2}" -f $script:psPath, $ScriptPath, $Arguments
        if ($Unregister)
        {
            Register-PowershellScheduler -ScheduleName $ScheduleName -Command $psCommand -Unregister
        }
        elseif ($Disabled)
        {
            Register-PowershellScheduler -ScheduleName $ScheduleName -Command $psCommand -Disabled
        }
        else
        {
            Register-PowershellScheduler -ScheduleName $ScheduleName -Command $psCommand
        }
    }
    catch
    {
        Write-Log ("Failed to schedule a task: {0}" -f $_.Exception.Message)
    }  
}
