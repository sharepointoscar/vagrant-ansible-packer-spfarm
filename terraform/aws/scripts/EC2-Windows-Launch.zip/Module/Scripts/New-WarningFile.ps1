# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

function New-WarningFile
{
    param (
        [parameter(Mandatory=$false)]
        [string] $DriveLetter
    )

    try 
    {
        # Important.txt must be created in each drive.
        Write-Log ("Creating 'Instance Store' warning file in drive {0}" -f $DriveLetter)
        $drivePath = "{0}:\" -f $DriveLetter
        $path = Join-Path $drivePath -ChildPath "Important.txt"
        $message = "This is an 'Instance Store' disk and is provided at no additional charge.`n`n" + 
                    "*This disk offers increased performance since it is local to the host`n" +
                    "*The number of Instance Store disks available to an instance vary by instance type`n" +
                    "*DATA ON THIS DRIVE WILL BE LOST IN CASES OF IMPAIRMENT OR STOPPING THE INSTANCE. PLEASE ENSURE THAT ANY IMPORTANT DATA IS BACKED UP FREQUENTLY`n`n" +
                    "For more information, please refer to: http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/InstanceStorage.html"
        New-Item -Path $path -ItemType File -Value $message | Out-Null
    }
    catch
    {
        Write-Log ("Unable to create 'Instance Store' warning file on drive {0}" -f $DriveLetter)
    }
}