# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Wait-Sysprep repeatedly checks for sysprep completion by checking registry key.
    Script always must wait for sysprep to be complete for the first stage.
-------------------------------------------------------------------------------------------------------------#>
function Wait-Sysprep
{
    # Nano Server doesn't support Sysprep. So we need to check if current platform is Nano Server.
    # Otherwise, it will fall into infinite loop if it is Nano Server.
    if (Test-NanoServer)
    {
        return
    }

    $expectedState = "IMAGE_STATE_COMPLETE"
    $setupStateKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\State"
    $sleepTime = 1
    $count = 0

    while ($true)
    {
        try 
        {
            # Sysprep state must be IMAGE_STATE_COMPLETE to continue.
            $currentImageState = (Get-ItemProperty -Path $setupStateKey).ImageState
            if ($currentImageState -eq $expectedState) 
            {
                Write-Log "Windows sysprep configuration complete." -LogToConsole
                break
            }
        } 
        catch 
        {
            Write-Log "Warning: Unable to determine SysprepState"
        }
        
        if ($count -eq 0) 
        {
            Write-Log ("Windows is being configured. SysprepState={0}" -f $currentImageState) -LogToConsole
        }
        elseif (($count * $sleepTime) % 60 -eq 0)
        {
            # This message will be logged to log file every 1 minute
            Write-Log ("Windows is still being configured. SysprepState={0}" -f $currentImageState)
        }

        Start-Sleep -seconds $sleepTime
        $count++
    }
}
