# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

<#-----------------------------------------------------------------------------------------------------------
    Set-ComputerName renames the computer based on ip address from metadata.
    i.e. Computer with 172.0.0.0 is renamed to ip-172000.
-------------------------------------------------------------------------------------------------------------#>
function Set-ComputerName
{
    $state = Get-LaunchConfig -Key SetComputerName
    if (-not $state) 
    {
        Write-Log "Setting computer name is disabled"
        return $false
    }

    try
    {
        $ipAddressFromMetadata = Get-Metadata -UrlFragment "meta-data/local-ipv4"
        $ipAddress = [IPAddress] $ipAddressFromMetadata.Trim()
        $numbers = $ipAddress.GetAddressBytes()

        if ($numbers.Length -ne 4)
        {
            Write-Log "Invalid IP Address returned by metadata service!"
            return $false
        }

        $currentHostName = [System.Net.Dns]::GetHostName()
        $newHostName = "IP-{0:X2}{1:X2}{2:X2}{3:X2}" -f $numbers[0], $numbers[1], $numbers[2], $numbers[3]

        Write-Log ("Hostname : {0}" -f $newHostName)
        Write-Log ("Current computer Hostname : {0}" -f $currentHostName)

        if ($newHostName -ieq $currentHostName)
        {
            Write-Log "Hostname is already set."
            return $false
        }

        Write-Log ("Attempting to rename host to: {0}" -f $newHostName)
    
        # If computer is renamed successfully, return true to request reboot.
        Rename-Computer -ComputerName $currentHostName -NewName $newHostName -Force -ErrorAction Stop
        Write-Log ("Host rename complete. Reboot has been queued.")
        return $true
    }
    catch
    {
        Write-Log ("Host Rename Failed. {0}" -f $_.Exception.Message)
    }

    return $false
}
